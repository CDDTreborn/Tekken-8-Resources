Disclaimer: I did not make the updated header, credit goes to A5tronomy and Remix for the assistance.
Peek also has an updated fork with more code updates available on his GitHub, I'll include his instructions below as well.

Instructions:

1. Download the Polaris.z7 and unzip.

2. Navigate to the root folder of your project in Windows Explorer.

TIP: If you have space, make a duplicate copy of your project in case things go wrong for some reason.

3. Open the Polaris folder that was unzipped and copy the "Source" folder

4. You should already have "Source" folder in your root project. Paste the new "Source" folder there. If it asks to replace items then say "OK".

5. Open the .sln in your project's root folder and open up Visual Studio

NOTE: If your custom UE is open then make sure it is closed before you try to "Build"

6. On the right-hand side there will be a hierarchy of the files within the solution (.sln). R-click "Polaris" and pick "Build"

7. This may take a few minutes. When completed you may get warnings but there should be no errors.

8. Open your project and all of the BI assets will be updated.

TIP: When making changes to a project is not uncommon for assets to disconnect (e.g. Textures no longer assigned to MI or assets not being assigned within an asset like an IP). Double-check before re-packaging.

Peeks Fix Instructions:
@everyone - I made some updates to the C++ headers and source in my mm_mi_tex branch of my fork of Koenji's project which should fix the BI issue.  You can see my changes in https://github.com/peek6/Polaris-Project/commit/d5f681215d0e345bb5eb77debf19e317fc030e47 .  It looks very similar to what @a5tronomy was doing.  I had also made some edits to the C++ code in previous updates which I included in this commit.  I confirmed that if I build in VS (with the UE project closed) and then re-open the UE project, the new DropItemInfo struct gets added to the BIs and reloading the BIs and repackaging my mods makes them work again, even with the isCommonItem box remaining checked .
 