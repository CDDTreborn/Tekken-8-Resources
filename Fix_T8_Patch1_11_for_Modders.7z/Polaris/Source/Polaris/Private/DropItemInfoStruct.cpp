#include "DropItemInfoStruct.h"

FDropItemInfoStruct::FDropItemInfoStruct() {
    this->DropItemImpulsePower = 0.00f;
    this->IsDropItemImpulseDirEnable = false;
    this->DropItemActor = NULL;
}

