bl_info = {
    "name": "Texture Baker – Multi Map (Consolidated)",
    "author": "You + ChatGPT",
    "version": (0, 3, 0),
    "blender": (3, 6, 0),
    "location": "3D Viewport > Sidebar > Texture Baker",
    "description": "Builds temporary setups and bakes consolidated textures (RMA, MRA, OBD, TSE, Normal, Color, ID, Diffuse) for selected objects using the active UV. Includes quick UV / blend / weight / material utilities.",
    "category": "Material",
}

import bpy
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import (
    EnumProperty,
    BoolProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from mathutils import Vector

TEMP_PREFIX = "TB_TEMP_"


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def debug_print(settings, *args):
    if settings.debug_mode:
        print("[TextureBaker]", *args)


def get_principled_bsdf(mat):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    for node in mat.node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            return node
    return None


def find_ao_node(mat):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    for node in mat.node_tree.nodes:
        if node.type == 'AMBIENT_OCCLUSION':
            return node
    return None


def get_material_output(mat):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return None
    out_nodes = [n for n in mat.node_tree.nodes if n.type == 'OUTPUT_MATERIAL']
    if not out_nodes:
        return None
    for n in out_nodes:
        if getattr(n, "is_active_output", False):
            return n
    return out_nodes[0]


def get_map_suffix(map_type: str) -> str:
    return {
        'RMA': "_RMA",
        'MRA': "_MRA",
        'OBD': "_OBD",
        'TSE': "_TSE",
        'N':   "_N",
        'PC':  "_PC",
        'ID':  "_ID",
        'C':   "_C",
    }.get(map_type, "_MAP")


def ensure_image_for_map(settings, map_type, context):
    active = context.view_layer.objects.active
    base_name = active.name if active else "Baked"
    img_name = base_name + get_map_suffix(map_type)
    img = bpy.data.images.get(img_name)
    if img is None:
        img = bpy.data.images.new(
            img_name,
            width=settings.resolution_x,
            height=settings.resolution_y,
            alpha=True,
            float_buffer=False,
        )
    return img


def clear_temp_nodes_from_material(mat, settings):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return

    nt = mat.node_tree

    # Restore Material Output to a non-temp Principled if possible
    out = get_material_output(mat)
    if out:
        original_pb = None
        for node in nt.nodes:
            if node.type == 'BSDF_PRINCIPLED' and not node.name.startswith(TEMP_PREFIX):
                original_pb = node
                break
        if original_pb:
            nt.links.new(original_pb.outputs.get('BSDF'), out.inputs['Surface'])
            debug_print(settings, f"Restored Material Output to {original_pb.name} in {mat.name}")

    # Remove temp nodes
    to_remove = [n for n in nt.nodes if n.name.startswith(TEMP_PREFIX)]
    for n in to_remove:
        debug_print(settings, f"Removing temp node {n.name} in {mat.name}")
        nt.nodes.remove(n)


# Helper to create a temp Principled + Image node and hook it to Output
def create_temp_principled_and_image(mat, settings, shared_image, map_type):
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        return None, None, None

    temp_pb = nt.nodes.new("ShaderNodeBsdfPrincipled")
    temp_pb.name = f"{TEMP_PREFIX}Principled_{map_type}"
    temp_pb.label = f"TB TEMP Principled ({map_type})"
    temp_pb.location = pb.location + Vector((350.0, 0.0))

    img_node = nt.nodes.new("ShaderNodeTexImage")
    img_node.name = f"{TEMP_PREFIX}Image_{map_type}"
    img_node.label = f"TB TEMP Image ({map_type})"
    img_node.image = shared_image
    img_node.location = temp_pb.location + Vector((250.0, 0.0))

    # Make sure this image node is the active one for this material
    nt.nodes.active = img_node

    nt.links.new(temp_pb.outputs['BSDF'], out.inputs['Surface'])

    # Ensure emission strength is 1.0 if present
    emission_strength_input = temp_pb.inputs.get("Emission Strength")
    if emission_strength_input is not None:
        emission_strength_input.default_value = 1.0

    return temp_pb, img_node, out


def connect_emission_color(temp_pb, color_socket, settings, mat):
    # Version-safe emission input
    emission_input = temp_pb.inputs.get("Emission") or temp_pb.inputs.get("Emission Color")
    if emission_input is not None:
        temp_pb.id_data.links.new(color_socket, emission_input)
        debug_print(settings, f"Connected color to Emission of {temp_pb.name} in {mat.name}")
    else:
        debug_print(settings, f"WARNING: No Emission input found on {temp_pb.name} in {mat.name}")


# ---------------------------------------------------------------------------
# Per-map material preparation
# ---------------------------------------------------------------------------

def prepare_material_for_rma(mat, settings, shared_image, report_data):
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)

    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "RMA")
    if temp_pb is None:
        return

    combine = nt.nodes.new("ShaderNodeCombineColor")
    combine.name = f"{TEMP_PREFIX}Combine_RMA"
    combine.label = "TB TEMP Combine (RMA)"
    combine.mode = 'RGB'
    combine.location = pb.location + Vector((150.0, -150.0))

    # AO logic
    ao_node = find_ao_node(mat)
    if ao_node:
        debug_print(settings, f"Using existing AO node {ao_node.name} in {mat.name}")
    elif settings.generate_ao:
        ao_node = nt.nodes.new("ShaderNodeAmbientOcclusion")
        ao_node.name = f"{TEMP_PREFIX}AO_RMA"
        ao_node.label = "TB TEMP AO (RMA)"
        ao_node.location = pb.location + Vector((-150.0, -250.0))
        ao_node.inputs["Color"].default_value = (1.0, 1.0, 1.0, 1.0)
        ao_node.samples = 64
        ao_node.inside = False
        ao_node.only_local = True
        dist_input = ao_node.inputs.get("Distance")
        if dist_input is not None:
            dist_input.default_value = 10.0

        normal_input = pb.inputs.get("Normal")
        if normal_input and normal_input.is_linked:
            from_socket = normal_input.links[0].from_socket
            nt.links.new(from_socket, ao_node.inputs["Normal"])
            debug_print(settings, f"Connected normal chain to AO in {mat.name}")
    else:
        debug_print(settings, f"No AO used in {mat.name}; Blue will be 1.0")

    # Roughness -> R
    rough_input = pb.inputs.get("Roughness")
    if rough_input:
        if rough_input.is_linked:
            from_socket = rough_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Red"])
        else:
            combine.inputs["Red"].default_value = rough_input.default_value

    # Metallic -> G
    metal_input = pb.inputs.get("Metallic")
    if metal_input:
        if metal_input.is_linked:
            from_socket = metal_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Green"])
        else:
            combine.inputs["Green"].default_value = metal_input.default_value

    # AO -> B or 1.0
    if ao_node:
        out_socket = ao_node.outputs.get("AO") or ao_node.outputs.get("Color")
        if out_socket:
            nt.links.new(out_socket, combine.inputs["Blue"])
        else:
            combine.inputs["Blue"].default_value = 1.0
    else:
        combine.inputs["Blue"].default_value = 1.0

    connect_emission_color(temp_pb, combine.outputs["Color"], settings, mat)


def prepare_material_for_mra(mat, settings, shared_image, report_data):
    # Metallic → R, Roughness → G, AO → B (same AO logic as RMA)
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)

    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "MRA")
    if temp_pb is None:
        return

    combine = nt.nodes.new("ShaderNodeCombineColor")
    combine.name = f"{TEMP_PREFIX}Combine_MRA"
    combine.label = "TB TEMP Combine (MRA)"
    combine.mode = 'RGB'
    combine.location = pb.location + Vector((150.0, -150.0))

    # AO logic same as RMA
    ao_node = find_ao_node(mat)
    if ao_node:
        debug_print(settings, f"Using existing AO node {ao_node.name} in {mat.name}")
    elif settings.generate_ao:
        ao_node = nt.nodes.new("ShaderNodeAmbientOcclusion")
        ao_node.name = f"{TEMP_PREFIX}AO_MRA"
        ao_node.label = "TB TEMP AO (MRA)"
        ao_node.location = pb.location + Vector((-150.0, -250.0))
        ao_node.inputs["Color"].default_value = (1.0, 1.0, 1.0, 1.0)
        ao_node.samples = 64
        ao_node.inside = False
        ao_node.only_local = True
        dist_input = ao_node.inputs.get("Distance")
        if dist_input is not None:
            dist_input.default_value = 10.0
        normal_input = pb.inputs.get("Normal")
        if normal_input and normal_input.is_linked:
            from_socket = normal_input.links[0].from_socket
            nt.links.new(from_socket, ao_node.inputs["Normal"])
    else:
        debug_print(settings, f"No AO used in {mat.name}; Blue will be 1.0")

    # Metallic -> R
    metal_input = pb.inputs.get("Metallic")
    if metal_input:
        if metal_input.is_linked:
            from_socket = metal_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Red"])
        else:
            combine.inputs["Red"].default_value = metal_input.default_value

    # Roughness -> G
    rough_input = pb.inputs.get("Roughness")
    if rough_input:
        if rough_input.is_linked:
            from_socket = rough_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Green"])
        else:
            combine.inputs["Green"].default_value = rough_input.default_value

    # AO -> B or 1.0
    if ao_node:
        out_socket = ao_node.outputs.get("AO") or ao_node.outputs.get("Color")
        if out_socket:
            nt.links.new(out_socket, combine.inputs["Blue"])
        else:
            combine.inputs["Blue"].default_value = 1.0
    else:
        combine.inputs["Blue"].default_value = 1.0

    connect_emission_color(temp_pb, combine.outputs["Color"], settings, mat)


def prepare_material_for_obd(mat, settings, shared_image, report_data):
    # R = Alpha, G = 0.0, B = 0.0
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "OBD")
    if temp_pb is None:
        return

    combine = nt.nodes.new("ShaderNodeCombineColor")
    combine.name = f"{TEMP_PREFIX}Combine_OBD"
    combine.label = "TB TEMP Combine (OBD)"
    combine.mode = 'RGB'
    combine.location = pb.location + Vector((150.0, -150.0))

    alpha_input = pb.inputs.get("Alpha")
    if alpha_input:
        if alpha_input.is_linked:
            from_socket = alpha_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Red"])
        else:
            combine.inputs["Red"].default_value = alpha_input.default_value
    combine.inputs["Green"].default_value = 0.0
    combine.inputs["Blue"].default_value = 0.0

    connect_emission_color(temp_pb, combine.outputs["Color"], settings, mat)


def prepare_material_for_tse(mat, settings, shared_image, report_data):
    # R = 0.0, G = Specular/IOR Level, B = Emission input (0.0 if unlinked)
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "TSE")
    if temp_pb is None:
        return

    combine = nt.nodes.new("ShaderNodeCombineColor")
    combine.name = f"{TEMP_PREFIX}Combine_TSE"
    combine.label = "TB TEMP Combine (TSE)"
    combine.mode = 'RGB'
    combine.location = pb.location + Vector((150.0, -150.0))

    # R = 0.0
    combine.inputs["Red"].default_value = 0.0

    # G = Specular IOR Level (4.x) or Specular (3.x)
    spec_input = pb.inputs.get("Specular IOR Level") or pb.inputs.get("Specular")
    if spec_input:
        if spec_input.is_linked:
            from_socket = spec_input.links[0].from_socket
            nt.links.new(from_socket, combine.inputs["Green"])
        else:
            combine.inputs["Green"].default_value = spec_input.default_value
    else:
        combine.inputs["Green"].default_value = 0.0

    # B = Emission input if linked, else 0.0
    emis_input = pb.inputs.get("Emission") or pb.inputs.get("Emission Color")
    if emis_input and emis_input.is_linked:
        from_socket = emis_input.links[0].from_socket
        nt.links.new(from_socket, combine.inputs["Blue"])
    else:
        combine.inputs["Blue"].default_value = 0.0

    connect_emission_color(temp_pb, combine.outputs["Color"], settings, mat)


def prepare_material_for_pc(mat, settings, shared_image, report_data):
    """
    Color (PC): Base Color + alpha using a Transparent/Emission mix, baked with Combined.
    """
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    # Source color from Base Color
    base_input = pb.inputs.get("Base Color")
    if base_input and base_input.is_linked:
        color_socket = base_input.links[0].from_socket
    else:
        # Create an RGB node with the default base color
        rgb_node = nt.nodes.new("ShaderNodeRGB")
        rgb_node.name = f"{TEMP_PREFIX}BaseColor_PC"
        rgb_node.label = "TB TEMP BaseColor (PC)"
        rgb_node.location = pb.location + Vector((-200.0, 0.0))
        if base_input:
            rgb_node.outputs["Color"].default_value = base_input.default_value
        color_socket = rgb_node.outputs["Color"]

    # Alpha from Principled Alpha (linked or value) – default to 1.0
    alpha_input = pb.inputs.get("Alpha")
    if alpha_input and alpha_input.is_linked:
        alpha_socket = alpha_input.links[0].from_socket
    else:
        # Use value as scalar; if no input, default to 1.0
        alpha_value = alpha_input.default_value if alpha_input else 1.0
        val_node = nt.nodes.new("ShaderNodeValue")
        val_node.name = f"{TEMP_PREFIX}Alpha_PC"
        val_node.label = "TB TEMP Alpha (PC)"
        val_node.location = pb.location + Vector((-200.0, -200.0))
        val_node.outputs[0].default_value = alpha_value
        alpha_socket = val_node.outputs[0]

    # Build Transparent/Emission mix
    transp = nt.nodes.new("ShaderNodeBsdfTransparent")
    transp.name = f"{TEMP_PREFIX}Transparent_PC"
    transp.label = "TB TEMP Transparent (PC)"
    transp.location = pb.location + Vector((150.0, 0.0))

    emis = nt.nodes.new("ShaderNodeEmission")
    emis.name = f"{TEMP_PREFIX}Emission_PC"
    emis.label = "TB TEMP Emission (PC)"
    emis.location = pb.location + Vector((150.0, -150.0))
    nt.links.new(color_socket, emis.inputs["Color"])

    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.name = f"{TEMP_PREFIX}Mix_PC"
    mix.label = "TB TEMP Mix (PC)"
    mix.location = pb.location + Vector((350.0, -50.0))
    nt.links.new(transp.outputs["BSDF"], mix.inputs[1])
    nt.links.new(emis.outputs["Emission"], mix.inputs[2])
    nt.links.new(alpha_socket, mix.inputs["Fac"])

    # Temp image node
    img_node = nt.nodes.new("ShaderNodeTexImage")
    img_node.name = f"{TEMP_PREFIX}Image_PC"
    img_node.label = "TB TEMP Image (PC)"
    img_node.image = shared_image
    img_node.location = mix.location + Vector((250.0, 0.0))
    nt.nodes.active = img_node

    out = get_material_output(mat)
    nt.links.new(mix.outputs["Shader"], out.inputs["Surface"])


def prepare_material_for_id(mat, settings, shared_image, report_data):
    # Base Color → Emission → Emit bake
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "ID")
    if temp_pb is None:
        return

    base_input = pb.inputs.get("Base Color")
    if base_input and base_input.is_linked:
        color_socket = base_input.links[0].from_socket
        connect_emission_color(temp_pb, color_socket, settings, mat)
    elif base_input:
        rgb_node = nt.nodes.new("ShaderNodeRGB")
        rgb_node.name = f"{TEMP_PREFIX}BaseColor_ID"
        rgb_node.label = "TB TEMP BaseColor (ID)"
        rgb_node.location = pb.location + Vector((-200.0, 0.0))
        rgb_node.outputs["Color"].default_value = base_input.default_value
        connect_emission_color(temp_pb, rgb_node.outputs["Color"], settings, mat)


def prepare_material_for_diffuse(mat, settings, shared_image, report_data):
    # Diffuse (C): Base Color; optional greyscale via HSV + Bright/Contrast; Emit bake
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree
    pb = get_principled_bsdf(mat)
    if pb is None:
        msg = f"Skipped material '{mat.name}' (no Principled BSDF)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    clear_temp_nodes_from_material(mat, settings)
    pb = get_principled_bsdf(mat)
    out = get_material_output(mat)
    if pb is None or out is None:
        msg = f"Skipped material '{mat.name}' after cleanup (no PB or output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    temp_pb, img_node, _ = create_temp_principled_and_image(mat, settings, shared_image, "C")
    if temp_pb is None:
        return

    base_input = pb.inputs.get("Base Color")

    # Determine source color socket
    if base_input and base_input.is_linked:
        src_socket = base_input.links[0].from_socket
    else:
        rgb_node = nt.nodes.new("ShaderNodeRGB")
        rgb_node.name = f"{TEMP_PREFIX}BaseColor_C"
        rgb_node.label = "TB TEMP BaseColor (C)"
        rgb_node.location = pb.location + Vector((-200.0, 0.0))
        if base_input:
            rgb_node.outputs["Color"].default_value = base_input.default_value
        src_socket = rgb_node.outputs["Color"]

    color_socket = src_socket

    # Optional greyscale pipeline
    if settings.diffuse_grayscale:
        hsv = nt.nodes.new("ShaderNodeHueSaturation")
        hsv.name = f"{TEMP_PREFIX}HSV_C"
        hsv.label = "TB TEMP HSV (C)"
        hsv.location = pb.location + Vector((0.0, -150.0))
        hsv.inputs["Saturation"].default_value = 0.0
        nt.links.new(src_socket, hsv.inputs["Color"])

        bc = nt.nodes.new("ShaderNodeBrightContrast")
        bc.name = f"{TEMP_PREFIX}BC_C"
        bc.label = "TB TEMP Bright/Contrast (C)"
        bc.location = hsv.location + Vector((200.0, 0.0))
        bc.inputs["Bright"].default_value = 0.1
        nt.links.new(hsv.outputs["Color"], bc.inputs["Color"])

        color_socket = bc.outputs["Color"]

    connect_emission_color(temp_pb, color_socket, settings, mat)


def prepare_material_for_normal(mat, settings, shared_image, report_data):
    # Only ensure an Image Texture node for the normal bake
    if not mat or not mat.use_nodes or not mat.node_tree:
        return
    nt = mat.node_tree

    clear_temp_nodes_from_material(mat, settings)
    out = get_material_output(mat)
    if out is None:
        msg = f"Skipped material '{mat.name}' (no Material Output)."
        report_data["skipped"].append(msg)
        debug_print(settings, msg)
        return

    img_node = nt.nodes.new("ShaderNodeTexImage")
    img_node.name = f"{TEMP_PREFIX}Image_N"
    img_node.label = "TB TEMP Image (N)"
    img_node.image = shared_image
    img_node.location = out.location + Vector((250.0, 0.0))
    nt.nodes.active = img_node


# ---------------------------------------------------------------------------
# Dispatcher for selected objects
# ---------------------------------------------------------------------------

def prepare_selected_objects_for_map(context, settings):
    map_type = settings.map_type
    shared_image = ensure_image_for_map(settings, map_type, context)
    report_data = {"skipped": [], "processed": []}

    for obj in context.selected_objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            mat = slot.material
            if not mat:
                continue

            if map_type == 'RMA':
                prepare_material_for_rma(mat, settings, shared_image, report_data)
            elif map_type == 'MRA':
                prepare_material_for_mra(mat, settings, shared_image, report_data)
            elif map_type == 'OBD':
                prepare_material_for_obd(mat, settings, shared_image, report_data)
            elif map_type == 'TSE':
                prepare_material_for_tse(mat, settings, shared_image, report_data)
            elif map_type == 'PC':
                prepare_material_for_pc(mat, settings, shared_image, report_data)
            elif map_type == 'ID':
                prepare_material_for_id(mat, settings, shared_image, report_data)
            elif map_type == 'C':
                prepare_material_for_diffuse(mat, settings, shared_image, report_data)
            elif map_type == 'N':
                prepare_material_for_normal(mat, settings, shared_image, report_data)

            report_data["processed"].append(mat.name)

    # Make sure one of the image nodes on the active object is active for baking
    active_obj = context.view_layer.objects.active
    if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
        image_node_name = f"{TEMP_PREFIX}Image_{map_type}"
        if map_type == 'N':
            image_node_name = f"{TEMP_PREFIX}Image_N"

        for slot in active_obj.material_slots:
            mat = slot.material
            if not mat or not mat.use_nodes or not mat.node_tree:
                continue
            for node in mat.node_tree.nodes:
                if node.name == image_node_name:
                    mat.node_tree.nodes.active = node
                    debug_print(settings, f"Set active image node {node.name} in {mat.name}")
                    break
            else:
                continue
            break

    return shared_image, report_data


def clear_all_temp_nodes(context, settings):
    for obj in context.selected_objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            mat = slot.material
            if mat:
                clear_temp_nodes_from_material(mat, settings)


# ---------------------------------------------------------------------------
# Quick Tools Utilities
# ---------------------------------------------------------------------------

def _material_duplicate_mapping(context):
    """
    Build a mapping of duplicate material names to their base materials
    among selected objects only.

    Example: 'Mat.001' -> 'Mat' (if 'Mat' exists).
    """
    mapping = {}
    for obj in context.selected_objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            mat = slot.material
            if not mat:
                continue
            name = mat.name
            parts = name.rsplit('.', 1)
            if len(parts) == 2 and parts[1].isdigit():
                base_name = parts[0]
                if base_name in bpy.data.materials:
                    mapping[name] = base_name
    return mapping

# ---------------------------- #
# UV Consolidation Functions   #
# ---------------------------- #

def tb_create_and_set_active_uv_map(context, settings):
    """
    Ensure each selected mesh has a UV map with the desired name.
    If override is enabled: reuse or create that exact name.
    If override is disabled: always create a new layer (Blender will suffix .001, .002, ...).
    """
    uv_name = settings.consolidated_uv_name.strip() or "Consolidated"
    meshes = [o for o in context.selected_objects if o.type == 'MESH']

    for obj in meshes:
        me = obj.data
        if not me.uv_layers:
            # No UVs at all – just create the target map so pack can work on something
            if settings.consolidated_uv_override:
                uv_map = me.uv_layers.get(uv_name)
                if uv_map is None:
                    uv_map = me.uv_layers.new(name=uv_name)
            else:
                uv_map = me.uv_layers.new(name=uv_name)
            me.uv_layers.active = uv_map
            continue

        if settings.consolidated_uv_override:
            uv_map = me.uv_layers.get(uv_name)
            if uv_map is None:
                uv_map = me.uv_layers.new(name=uv_name)
        else:
            uv_map = me.uv_layers.new(name=uv_name)

        me.uv_layers.active = uv_map


def tb_pack_uv_islands_for_selected(context, settings):
    """
    Multi-object pack:
    - Uses whatever UV map is currently active on each mesh (we just set it to the consolidated one).
    - Runs the same sequence you used in your 3.6 script:
      reveal → uv.select_all → average_islands_scale → pin → pack → unpin.
    """
    meshes = [o for o in context.selected_objects if o.type == 'MESH']
    if not meshes:
        return 0

    # Remember selection / active / mode
    prev_active = context.view_layer.objects.active
    prev_mode = prev_active.mode if prev_active else 'OBJECT'
    prev_selection = [obj for obj in context.view_layer.objects if obj.select_get()]

    # Make sure we're in Object Mode
    if context.object and context.object.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

    processed = 0

    try:
        # Select only our meshes and go into multi-object edit
        bpy.ops.object.select_all(action='DESELECT')
        for obj in meshes:
            obj.select_set(True)
        context.view_layer.objects.active = meshes[0]

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_mode(type='FACE')
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.uv.select_all(action='SELECT')
        bpy.ops.uv.average_islands_scale()

        # Pin all, pack, then clear pins – just like your 3.6 version
        bpy.ops.uv.pin()
        try:
            bpy.ops.uv.pack_islands(
                shape_method='CONCAVE',
                rotate=False,
                margin=0.003,
                margin_method='SCALED'
            )
        except TypeError:
            # Fallback if some future version changes arguments
            bpy.ops.uv.pack_islands(margin=0.003)

        bpy.ops.uv.select_all(action='SELECT')
        bpy.ops.uv.pin(clear=True)

        bpy.ops.object.mode_set(mode='OBJECT')
        processed = len(meshes)

    except Exception as e:
        debug_print(settings, f"UV pack failed: {e}")
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

    # Restore previous selection / active / mode
    bpy.ops.object.select_all(action='DESELECT')
    for obj in prev_selection:
        if obj and obj.name in context.view_layer.objects:
            obj.select_set(True)

    if prev_active and prev_active.name in context.view_layer.objects:
        context.view_layer.objects.active = prev_active
        try:
            bpy.ops.object.mode_set(mode=prev_mode)
        except Exception:
            pass

    return processed


def tb_consolidate_uvs(context, settings):
    """
    High-level UV consolidation entry point: mirrors your old 3.6 behavior but
    uses the add-on settings (name + override) and is safe across 3.6–4.5.
    """
    tb_create_and_set_active_uv_map(context, settings)
    return tb_pack_uv_islands_for_selected(context, settings)

# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------

class TEXTUREBAKER_Settings(PropertyGroup):

    # Existing bake map controls
    map_type: EnumProperty(
        name="Map Type",
        description="Type of map to build",
        items=[
            ('RMA', "RMA (R, M, AO)", "Roughness → R, Metallic → G, AO → B"),
            ('MRA', "MRA (M, R, AO)", "Metallic → R, Roughness → G, AO → B"),
            ('OBD', "OBD (A, 0, 0)", "Alpha → R, G/B set to 0"),
            ('TSE', "TSE (0, Spec, Em)", "Translucency-style: 0 → R, Specular/IOR → G, Emission → B"),
            ('N',   "Normal", "Normal map bake"),
            ('PC',  "Color (PC)", "Base Color + Alpha"),
            ('ID',  "ID", "Base Color only"),
            ('C',   "Diffuse / Grey", "Base Color, optional greyscale via HSV + Bright/Contrast"),
        ],
        default='RMA',
    )

    generate_ao: BoolProperty(
        name="Generate AO if Missing",
        description="Create a temporary Ambient Occlusion node if the material has none (RMA/MRA/TSE)",
        default=True,
    )

    debug_mode: BoolProperty(
        name="Debug Print",
        description="Print verbose information to the console",
        default=False,
    )

    resolution_x: IntProperty(
        name="Width",
        description="Bake texture width",
        default=2048,
        min=64,
        max=16384,
    )

    resolution_y: IntProperty(
        name="Height",
        description="Bake texture height",
        default=2048,
        min=64,
        max=16384,
    )

    diffuse_grayscale: BoolProperty(
        name="Diffuse: Convert to Grayscale",
        description="For Diffuse (C) map: insert HSV + Bright/Contrast to make greyscale",
        default=False,
    )

    # --- Quick Weight Transfer options --------------------------------------
    auto_generate_data_layers: BoolProperty(
        name="Auto Generate Data Layers",
        description="Automatically run 'Generate Data Layers' for each Data Transfer modifier",
        default=True,
    )

    # --- NEW: Quick Tools settings -----------------------------------------

    consolidated_uv_name: StringProperty(
        name="UV Name",
        description="Name for the consolidated UV map created on all selected meshes",
        default="Consolidated",
    )

    consolidated_uv_override: BoolProperty(
        name="Override Existing",
        description="If enabled, reuse or create a UV map with this exact name; "
                    "if disabled, always create a new layer (which Blender will suffix .001, .002, ...)",
        default=True,
    )

    blend_mode: EnumProperty(
        name="Blend Mode",
        description="Set blend mode for all materials on selected meshes",
        items=[
            ('OPAQUE', "Opaque", "Fully opaque"),
            ('CLIP', "Alpha Clip", "Binary alpha cutout"),
            ('HASHED', "Alpha Hashed", "Dithered transparency"),
            ('BLEND', "Alpha Blend", "Standard alpha blending"),
        ],
        default='OPAQUE',
    )


# ---------------------------------------------------------------------------
# Operators – Bake System
# ---------------------------------------------------------------------------

class TEXTUREBAKER_OT_build_nodes(Operator):
    """Build / refresh temporary nodes for the selected map type (no bake yet)"""
    bl_idname = "texture_baker.build_nodes"
    bl_label = "Build Channel Mix"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings

        if not context.selected_objects:
            self.report({'WARNING'}, "No selected objects.")
            return {'CANCELLED'}

        prepare_selected_objects_for_map(context, settings)
        self.report({'INFO'}, f"Temporary setup built for map type: {settings.map_type}")
        return {'FINISHED'}


class TEXTUREBAKER_OT_bake(Operator):
    """Bake the current map type to a consolidated texture"""
    bl_idname = "texture_baker.bake"
    bl_label = "Bake"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings

        if not context.selected_objects:
            self.report({'WARNING'}, "No selected objects to bake.")
            return {'CANCELLED'}

        # Make sure we are in Object Mode
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Only meshes are valid bake targets
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not meshes:
            self.report({'WARNING'}, "No selected mesh objects to bake.")
            return {'CANCELLED'}

        # Ensure proper selection + active mesh for baking
        active_mesh = context.view_layer.objects.active
        if active_mesh not in meshes:
            active_mesh = meshes[0]
            context.view_layer.objects.active = active_mesh

        bpy.ops.object.select_all(action='DESELECT')
        for ob in meshes:
            ob.select_set(True)
        active_mesh.select_set(True)
        context.view_layer.objects.active = active_mesh

        # Build / refresh temp nodes and image
        img, report_data = prepare_selected_objects_for_map(context, settings)

        scene = context.scene
        scene.render.engine = 'CYCLES'

        # Decide bake type
        if settings.map_type == 'N':
            scene.cycles.bake_type = 'NORMAL'
        elif settings.map_type == 'PC':
            scene.cycles.bake_type = 'COMBINED'
        else:
            scene.cycles.bake_type = 'EMIT'

        debug_print(
            settings,
            f"Baking map {settings.map_type} to image '{img.name}' "
            f"({img.size[0]}x{img.size[1]}) on active mesh {active_mesh.name}"
        )

        # Speed up bake by lowering samples temporarily
        old_samples = scene.cycles.samples
        scene.cycles.samples = 4

        # Avoid clearing the shared image between objects/materials
        old_clear = scene.render.bake.use_clear
        scene.render.bake.use_clear = False

        # Ensure we are NOT in Selected to Active mode
        old_sta = scene.render.bake.use_selected_to_active
        scene.render.bake.use_selected_to_active = False

        try:
            bpy.ops.object.bake(type=scene.cycles.bake_type)
        except RuntimeError as e:
            self.report({'ERROR'}, f"Bake failed: {e}")
            return {'CANCELLED'}
        finally:
            scene.cycles.samples = old_samples
            scene.render.bake.use_clear = old_clear
            scene.render.bake.use_selected_to_active = old_sta

        if report_data["skipped"]:
            self.report(
                {'WARNING'},
                f"Bake finished. Skipped: {len(report_data['skipped'])} material(s). "
                "Check console for details."
            )
            for msg in report_data["skipped"]:
                debug_print(settings, msg)
        else:
            self.report({'INFO'}, "Bake finished successfully.")

        return {'FINISHED'}


class TEXTUREBAKER_OT_clear(Operator):
    """Clear all temporary nodes created by Texture Baker on selected objects"""
    bl_idname = "texture_baker.clear"
    bl_label = "Clear Temporary Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings
        clear_all_temp_nodes(context, settings)
        self.report({'INFO'}, "Cleared Texture Baker temporary nodes on selected objects.")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operators – Quick Tools
# ---------------------------------------------------------------------------

class TEXTUREBAKER_OT_consolidate_uvs(Operator):
    """Create a 'Consolidated' (or custom named) UV map on selected meshes and pack islands"""
    bl_idname = "texture_baker.consolidate_uvs"
    bl_label = "Consolidate UVs"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings

        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not meshes:
            self.report({'WARNING'}, "No selected mesh objects.")
            return {'CANCELLED'}

        processed = tb_consolidate_uvs(context, settings)

        if processed == 0:
            self.report({'WARNING'}, "No meshes were processed for UV consolidation.")
        else:
            uv_name = settings.consolidated_uv_name.strip() or "Consolidated"
            self.report({'INFO'}, f"Consolidated UV '{uv_name}' updated on {processed} mesh object(s).")

        return {'FINISHED'}




class TEXTUREBAKER_OT_set_blend_mode(Operator):
    """Set blend mode on all materials for selected meshes"""
    bl_idname = "texture_baker.set_blend_mode"
    bl_label = "Apply Blend Mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings
        mode = settings.blend_mode

        if not context.selected_objects:
            self.report({'WARNING'}, "No selected objects.")
            return {'CANCELLED'}

        mats_changed = 0
        meshes = [o for o in context.selected_objects if o.type == 'MESH']

        for obj in meshes:
            for slot in obj.material_slots:
                mat = slot.material
                if not mat:
                    continue

                # 3.x / 4.x compatibility
                if hasattr(mat, "blend_method"):
                    if mat.blend_method != mode:
                        mat.blend_method = mode
                        mats_changed += 1
                elif hasattr(mat, "blend_mode"):
                    if mat.blend_mode != mode:
                        mat.blend_mode = mode
                        mats_changed += 1

        if mats_changed == 0:
            self.report({'INFO'}, "No materials changed (nothing selected, or already set).")
        else:
            self.report({'INFO'}, f"Updated blend mode on {mats_changed} material slot(s).")
        return {'FINISHED'}


class TEXTUREBAKER_OT_add_weight_transfer_mods(Operator):
    """Add Data Transfer modifiers for quick weight transfer from active to other selected meshes"""
    bl_idname = "texture_baker.add_weight_transfer_mods"
    bl_label = "Add Weight Transfer Mods"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.texture_baker_settings

        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if len(meshes) < 2:
            self.report({'WARNING'}, "Select at least two mesh objects (active will be the source).")
            return {'CANCELLED'}

        # Remember original active + mode
        prev_active = context.view_layer.objects.active
        prev_mode = prev_active.mode if prev_active else 'OBJECT'

        # Ensure Object Mode
        if context.object and context.object.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        # Source = active mesh, or first in list
        source = context.view_layer.objects.active
        if source not in meshes:
            source = meshes[0]
            context.view_layer.objects.active = source

        added = 0
        for obj in meshes:
            if obj == source:
                continue

            dt = obj.modifiers.new(name="TB_WeightTransfer", type='DATA_TRANSFER')
            dt.object = source

            # Vertex group weights only
            dt.use_vert_data = True
            try:
                dt.data_types_verts = {'VGROUP_WEIGHTS'}
            except Exception:
                dt.data_types_verts = {'VGROUP_WEIGHTS'}

            # Mapping – safe across 3.6–4.5
            dt.vert_mapping = 'POLYINTERP_NEAREST'
            dt.use_object_transform = True

            # Optional max distance
            if hasattr(dt, "use_max_distance"):
                dt.use_max_distance = True
                dt.max_distance = 10.0

            dt.mix_mode = 'REPLACE'
            dt.mix_factor = 1.0

            # Optional: auto-generate data layers, based on user setting
            if settings.auto_generate_data_layers:
                try:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.datalayout_transfer(modifier=dt.name)
                except Exception as e:
                    debug_print(settings, f"Data layout transfer failed on {obj.name}: {e}")

            added += 1

        # Restore original active + mode
        if prev_active:
            context.view_layer.objects.active = prev_active
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except Exception:
                pass

        if settings.auto_generate_data_layers:
            msg = f"Added weight transfer modifiers + generated data layers on {added} mesh object(s). Source: {source.name}"
        else:
            msg = f"Added weight transfer modifiers on {added} mesh object(s). Source: {source.name} (Generate Data Layers manually)."

        self.report({'INFO'}, msg)
        return {'FINISHED'}





class TEXTUREBAKER_OT_clear_vertex_groups(Operator):
    """Delete all vertex groups from selected meshes"""
    bl_idname = "texture_baker.clear_vertex_groups"
    bl_label = "Delete Vertex Groups"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not meshes:
            self.report({'WARNING'}, "No selected mesh objects.")
            return {'CANCELLED'}

        cleared = 0
        for obj in meshes:
            if obj.vertex_groups:
                obj.vertex_groups.clear()
                cleared += 1

        if cleared == 0:
            self.report({'INFO'}, "No vertex groups found to delete.")
        else:
            self.report({'INFO'}, f"Deleted vertex groups on {cleared} mesh object(s).")
        return {'FINISHED'}


class TEXTUREBAKER_OT_cleanup_material_duplicates(Operator):
    """Replace duplicate materials (Mat.001, Mat.002, ...) with their base material (Mat) on selected meshes"""
    bl_idname = "texture_baker.cleanup_material_duplicates"
    bl_label = "Duplicate Material Cleanup"
    bl_options = {'REGISTER', 'UNDO'}

    material_report: StringProperty(
        name="Summary",
        default="",
        options={'HIDDEN'},
    )

    def invoke(self, context, event):
        mapping = _material_duplicate_mapping(context)
        if not mapping:
            self.report({'INFO'}, "No duplicate materials found among selected objects.")
            return {'CANCELLED'}

        lines = []
        for dup, base in sorted(mapping.items()):
            lines.append(f"{dup}  →  {base}")

        # Limit lines so the dialog doesn't get absurdly tall
        max_lines = 32
        if len(lines) > max_lines:
            shown = lines[:max_lines]
            shown.append(f"... and {len(lines) - max_lines} more.")
            lines = shown

        self.material_report = "\n".join(lines)
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.label(text="The following materials will be remapped:")
        for line in self.material_report.splitlines():
            layout.label(text=line)

    def execute(self, context):
        mapping = _material_duplicate_mapping(context)
        if not mapping:
            self.report({'INFO'}, "No duplicate materials to remap.")
            return {'CANCELLED'}

        changes = 0
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for slot in obj.material_slots:
                mat = slot.material
                if not mat:
                    continue
                base_name = mapping.get(mat.name)
                if base_name:
                    base_mat = bpy.data.materials.get(base_name)
                    if base_mat:
                        slot.material = base_mat
                        changes += 1

        if changes == 0:
            self.report({'INFO'}, "No material slots were changed.")
        else:
            self.report({'INFO'}, f"Remapped {changes} material slot(s) to base materials.")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class TEXTUREBAKER_PT_panel(Panel):
    bl_label = "Texture Baker"
    bl_idname = "TEXTUREBAKER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Texture Baker"

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def draw(self, context):
        layout = self.layout
        settings = context.scene.texture_baker_settings
        
        row = layout.row()
        row.operator("wm.url_open", text="📘 Online Documentation").url = "https://github.com/CDDTreborn/Tekken-8-Resources/wiki/Texture-Baker-%E2%80%93-Blender-Add%E2%80%90On-%E2%80%90-Guide"


        # --- Bake Section ----------------------------------------------------
        col = layout.column(align=True)
        col.label(text="Map Settings:")
        col.prop(settings, "map_type", text="Type")
        col.prop(settings, "generate_ao")
        col.prop(settings, "debug_mode")

        if settings.map_type == 'C':
            col.prop(settings, "diffuse_grayscale")

        col.separator()
        col.label(text="Image Resolution:")
        row = col.row(align=True)
        row.prop(settings, "resolution_x")
        row.prop(settings, "resolution_y")

        col.separator()
        col.operator("texture_baker.build_nodes", text="Build / Refresh Setup")
        col.operator("texture_baker.bake", text="Bake")
        col.operator("texture_baker.clear", text="Clear Temporary Nodes")

class TEXTUREBAKER_PT_quick_tools(Panel):
    bl_label = "Quick Tools"
    bl_idname = "TEXTUREBAKER_PT_quick_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Texture Baker"

    # Make it a child of the main Texture Baker panel
    bl_parent_id = "TEXTUREBAKER_PT_panel"

    # Collapsed by default
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def draw(self, context):
        layout = self.layout
        settings = context.scene.texture_baker_settings

        layout.label(text="Quick Tools:")

        # Consolidate UVs
        box_uv = layout.box()
        box_uv.label(text="Consolidate UVs", icon='GROUP_UVS')
        row = box_uv.row(align=True)
        row.prop(settings, "consolidated_uv_name", text="Name")
        box_uv.prop(settings, "consolidated_uv_override")
        box_uv.operator("texture_baker.consolidate_uvs", text="Create / Pack UVs")

        # Blend Mode Switch
        box_blend = layout.box()
        box_blend.label(text="Blend Mode Switch", icon='MATERIAL')
        row = box_blend.row(align=True)
        row.prop(settings, "blend_mode", text="")
        box_blend.operator("texture_baker.set_blend_mode", text="Apply to Selected")

        # Quick Weight Transfer
        box_weight = layout.box()
        box_weight.label(text="Quick Weight Transfer", icon='MOD_DATA_TRANSFER')
        box_weight.prop(settings, "auto_generate_data_layers",
                        text="Auto-generate Data Layers")
        box_weight.operator("texture_baker.add_weight_transfer_mods",
                            text="Add Data Transfer Modifiers")
        box_weight.operator("texture_baker.clear_vertex_groups",
                            text="Delete Vertex Groups")


        # Duplicate Material Cleanup
        box_mat = layout.box()
        box_mat.label(text="Duplicate Material Cleanup", icon='NODE_MATERIAL')
        box_mat.operator("texture_baker.cleanup_material_duplicates",
                         text="Remap Duplicates → Base")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    TEXTUREBAKER_Settings,

    TEXTUREBAKER_OT_build_nodes,
    TEXTUREBAKER_OT_bake,
    TEXTUREBAKER_OT_clear,

    TEXTUREBAKER_OT_consolidate_uvs,
    TEXTUREBAKER_OT_set_blend_mode,
    TEXTUREBAKER_OT_add_weight_transfer_mods,
    TEXTUREBAKER_OT_clear_vertex_groups,
    TEXTUREBAKER_OT_cleanup_material_duplicates,

    TEXTUREBAKER_PT_panel,
    TEXTUREBAKER_PT_quick_tools,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.texture_baker_settings = PointerProperty(
        type=TEXTUREBAKER_Settings
    )


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Scene, "texture_baker_settings"):
        del bpy.types.Scene.texture_baker_settings


if __name__ == "__main__":
    register()
