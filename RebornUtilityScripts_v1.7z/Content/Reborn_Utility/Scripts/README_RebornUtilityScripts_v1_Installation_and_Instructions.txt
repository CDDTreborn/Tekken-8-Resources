In order to run python scripts you must enable the Python Editor Script Plugin.
If not enabled, go to Edit > Plugins and search for python and then enable it by checking the box.

RunOptimizeTexturesForT8

Installation:
Open Windows Explorer and copy RunOptimizeTexturesForT8.uasset into your project's root folder (the one with the .sln in it). Once it's in UE, feel free to move it wherever you see fit.

What does it do?
Based on the suffix (ending) of the selected texture(s) certain parameters will automatically be set. Not case sensitive.

Color/Diffuse = use _c or _pc 
Normal Maps = _n or _nor
ID Maps = _ID
Other Maps = _TSE, _OBD, _MRA, _RMA

Sets all textures
- Never Stream = True
- NoMipMaps
- Preserve Border = True

Sets all textures except Color/Diffuse
- sRGB False

Sets Other Maps and Color/Diffuse
- Texture Group = Character

Sets Normal Maps
- Texture Group = Character Normal Map

Sets ID Maps
- Texture Group = Vehicle
- Texture Compression = Vector Displacement Map
- If no alpha detected on import, sets Min and Max Alpha to 0

How to use it?

1. Select one or more Textures and right-click one of them.
2. Go to Scripted Asset Actions and select Optimize Textures for T8.

Note: It will only work on textures that end with the suffixes that I listed.