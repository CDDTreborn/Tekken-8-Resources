bl_info = {
    "name": "T8 Texture Tool",
    "description": "A tool for generating texture maps and managing material nodes.",
    "author": "CDDT Reborn",
    "version": (4, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > T8 Texture Tool",
    "warning": "",  # Leave empty for no warnings
    "doc_url": "",  # Optional: Add a link to documentation
    "category": "Material",
}

import bpy

# Function to apply the selected map type
def apply_map_type(material, map_type):
    # Remove existing Bake shader, custom nodes, and Divide Spec node if they exist
    for node in material.node_tree.nodes:
        if node.label in ["Bake", "RMA", "MRA", "OBD", "TSE", "Normal Map", "Divide Spec", "Divide Emission"]:
            material.node_tree.nodes.remove(node)

    # Create new Bake shader
    bake_shader = material.node_tree.nodes.new(type="ShaderNodeBsdfPrincipled")
    bake_shader.label = "Bake"
    bake_shader.location = (0, 0)

    # Create Combine RGB nodes
    combine_rma = material.node_tree.nodes.new(type="ShaderNodeCombineRGB")
    combine_rma.label = "RMA"
    combine_rma.location = (-300, 200)

    combine_mra = material.node_tree.nodes.new(type="ShaderNodeCombineRGB")
    combine_mra.label = "MRA"
    combine_mra.location = (-300, 0)

    combine_obd = material.node_tree.nodes.new(type="ShaderNodeCombineRGB")
    combine_obd.label = "OBD"
    combine_obd.location = (-300, -200)

    combine_tse = material.node_tree.nodes.new(type="ShaderNodeCombineRGB")
    combine_tse.label = "TSE"
    combine_tse.location = (-300, -400)

    # Link Bake shader to Material Output
    material_output = material.node_tree.nodes.get("Material Output")
    if material_output:
        material.node_tree.links.new(bake_shader.outputs["BSDF"], material_output.inputs["Surface"])

    # Link inputs from original shader to Combine RGB nodes
    original_shader = material.node_tree.nodes.get("Principled BSDF")
    if original_shader:
        input_mapping = {
            "Roughness": {
                "RMA": "R",
                "MRA": "G",
                "OBD": None,
                "TSE": None
            },
            "Metallic": {
                "RMA": "G",
                "MRA": "R",
                "OBD": None,
                "TSE": None
            },
            "Coat Weight": {
                "RMA": "B",
                "MRA": "B",
                "OBD": None,
                "TSE": None
            },
            "Alpha": {
                "RMA": None,
                "MRA": None,
                "OBD": "R",
                "TSE": None
            },
            "Dirt": {
                "RMA": None,
                "MRA": None,
                "OBD": "B",
                "TSE": None
            },
            "Translucency": {
                "RMA": None,
                "MRA": None,
                "OBD": None,
                "TSE": "R"
            },
            "Specular Tint": {
                "RMA": None,
                "MRA": None,
                "OBD": None,
                "TSE": "G"
            },
            "Emission Color": {
                "RMA": None,
                "MRA": None,
                "OBD": None,
                "TSE": "B"
            }
        }

        for input_name, channels in input_mapping.items():
            if input_name in original_shader.inputs:
                link = original_shader.inputs[input_name].links[0] if original_shader.inputs[input_name].is_linked else None
                if link:
                    # Transfer the link to the appropriate Combine RGB node
                    for map_type_key, channel in channels.items():
                        if channel:
                            if map_type_key == "RMA":
                                material.node_tree.links.new(link.from_socket, combine_rma.inputs[channel])
                            elif map_type_key == "MRA":
                                material.node_tree.links.new(link.from_socket, combine_mra.inputs[channel])
                            elif map_type_key == "OBD":
                                material.node_tree.links.new(link.from_socket, combine_obd.inputs[channel])
                            elif map_type_key == "TSE":
                                if input_name in ["Specular Tint", "Emission Color"]:
                                    # Divide the color by 1 and link to the TSE node
                                    math_node = material.node_tree.nodes.new(type="ShaderNodeMath")
                                    math_node.label = "Divide Spec" if input_name == "Specular Tint" else "Divide Emission"
                                    math_node.location = (-500, -400)
                                    math_node.operation = 'DIVIDE'
                                    math_node.inputs[1].default_value = 1.0
                                    material.node_tree.links.new(link.from_socket, math_node.inputs[0])
                                    material.node_tree.links.new(math_node.outputs[0], combine_tse.inputs[channel])
                                else:
                                    material.node_tree.links.new(link.from_socket, combine_tse.inputs[channel])
                else:
                    # Copy the default value to the appropriate Combine RGB node
                    value = original_shader.inputs[input_name].default_value
                    for map_type_key, channel in channels.items():
                        if channel:
                            if map_type_key == "RMA":
                                combine_rma.inputs[channel].default_value = value
                            elif map_type_key == "MRA":
                                combine_mra.inputs[channel].default_value = value
                            elif map_type_key == "OBD":
                                combine_obd.inputs[channel].default_value = value
                            elif map_type_key == "TSE":
                                if input_name in ["Specular Tint", "Emission Color"]:
                                    # Divide the color by 1 and link to the TSE node
                                    math_node = material.node_tree.nodes.new(type="ShaderNodeMath")
                                    math_node.label = "Divide Spec" if input_name == "Specular Tint" else "Divide Emission"
                                    math_node.location = (-500, -400)
                                    math_node.operation = 'DIVIDE'
                                    math_node.inputs[1].default_value = 1.0
                                    math_node.inputs[0].default_value = (value[0] + value[1] + value[2]) / 3
                                    material.node_tree.links.new(math_node.outputs[0], combine_tse.inputs[channel])
                                else:
                                    combine_tse.inputs[channel].default_value = value

        # Handle Base Color and Coat Tint based on selected map type
        if map_type == "Color":
            # Link Base Color to Emission Color
            if "Base Color" in original_shader.inputs:
                base_color_link = original_shader.inputs["Base Color"].links[0] if original_shader.inputs["Base Color"].is_linked else None
                if base_color_link:
                    material.node_tree.links.new(base_color_link.from_socket, bake_shader.inputs["Emission Color"])
                else:
                    bake_shader.inputs["Emission Color"].default_value = original_shader.inputs["Base Color"].default_value
        elif map_type == "ID":
            # Link Coat Tint to Emission Color
            if "Coat Tint" in original_shader.inputs:
                coat_tint_link = original_shader.inputs["Coat Tint"].links[0] if original_shader.inputs["Coat Tint"].is_linked else None
                if coat_tint_link:
                    material.node_tree.links.new(coat_tint_link.from_socket, bake_shader.inputs["Emission Color"])
                else:
                    # Default to full red (RGB 1, 0, 0)
                    bake_shader.inputs["Emission Color"].default_value = (1.0, 0.0, 0.0, 1.0)
        else:
            # Transfer Base Color from original shader to Bake shader
            if "Base Color" in original_shader.inputs:
                base_color_link = original_shader.inputs["Base Color"].links[0] if original_shader.inputs["Base Color"].is_linked else None
                if base_color_link:
                    material.node_tree.links.new(base_color_link.from_socket, bake_shader.inputs["Base Color"])
                else:
                    bake_shader.inputs["Base Color"].default_value = original_shader.inputs["Base Color"].default_value

        # Transfer Normal from original shader to Bake shader
        if "Normal" in original_shader.inputs:
            normal_link = original_shader.inputs["Normal"].links[0] if original_shader.inputs["Normal"].is_linked else None
            if normal_link:
                material.node_tree.links.new(normal_link.from_socket, bake_shader.inputs["Normal"])
            else:
                # Create a default Normal Map node
                normal_map_node = material.node_tree.nodes.new(type="ShaderNodeNormalMap")
                normal_map_node.label = "Normal Map"
                normal_map_node.location = (-500, -600)
                material.node_tree.links.new(normal_map_node.outputs["Normal"], bake_shader.inputs["Normal"])

    # Connect the selected Combine RGB node to the Bake shader's Emission Color (if not Color or ID)
    if map_type not in ["Color", "ID"]:
        if map_type == "RMA":
            material.node_tree.links.new(combine_rma.outputs["Image"], bake_shader.inputs["Emission Color"])
        elif map_type == "MRA":
            material.node_tree.links.new(combine_mra.outputs["Image"], bake_shader.inputs["Emission Color"])
        elif map_type == "OBD":
            material.node_tree.links.new(combine_obd.outputs["Image"], bake_shader.inputs["Emission Color"])
        elif map_type == "TSE":
            material.node_tree.links.new(combine_tse.outputs["Image"], bake_shader.inputs["Emission Color"])

# Function to reset the material
def reset_material(material):
    original_shader = material.node_tree.nodes.get("Principled BSDF")
    material_output = material.node_tree.nodes.get("Material Output")

    if original_shader and material_output:
        # Remove Bake shader, custom nodes, and Divide Spec node if they exist
        for node in material.node_tree.nodes:
            if node.label in ["Bake", "RMA", "MRA", "OBD", "TSE", "Normal Map", "Divide Spec", "Divide Emission"]:
                material.node_tree.nodes.remove(node)

        # Reconnect original shader to Material Output
        material.node_tree.links.new(original_shader.outputs["BSDF"], material_output.inputs["Surface"])

# Function to apply the selected map type to all selected mesh objects
def apply_to_selected_objects(map_type):
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            for material_slot in obj.material_slots:
                if material_slot.material:
                    apply_map_type(material_slot.material, map_type)

# Function to reset all selected mesh objects
def reset_selected_objects():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            for material_slot in obj.material_slots:
                if material_slot.material:
                    reset_material(material_slot.material)

# Function to show instructions in a pop-up window
def show_instructions(self, context):
    layout = self.layout
    layout.label(text="How to Use the T8 Texture Tool:")
    layout.label(text="1. Install free TexTools Addon for baking.")
    layout.label(text="2. Setup your materials as desired.")
    layout.label(text="3. Select all objects you want texture maps generated for.")
    layout.label(text="4. Choose your texture type and hit Apply.")
    layout.label(text="5. Use TexTools, select the Emission option in Bake.")
    layout.label(text="6. When complete, select all relevant objects and hit Reset to clear the excess nodes.")
    layout.separator()
    layout.label(text="Texture Type to Shader Input Table:")
    layout.label(text="Base Color = Color")
    layout.label(text="Normal = Normal")
    layout.label(text="Metallic = Metallic")
    layout.label(text="Roughness = Roughness")
    layout.label(text="Specular = Specular Tint")
    layout.label(text="AO = Coat Weight")
    layout.label(text="Emissive = Emission Color")
    layout.label(text="ID = Coat Tint")
    layout.separator()
    layout.label(text="Bake normals using Tangent Normal in TexTools.")

# UI Panel
class MAPTYPE_PT_Panel(bpy.types.Panel):
    bl_label = "T8 Texture Tool"
    bl_idname = "MAPTYPE_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T8 Texture Tool"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(context.scene, "map_type", text="Map Type")
        row = layout.row()
        row.operator("maptype.apply", text="Apply")
        row.operator("maptype.reset", text="Reset")
        row = layout.row()
        row.operator("maptype.instructions", text="Instructions")

# Apply Operator
class MAPTYPE_OT_Apply(bpy.types.Operator):
    bl_idname = "maptype.apply"
    bl_label = "Apply Map Type"

    def execute(self, context):
        apply_to_selected_objects(context.scene.map_type)
        return {'FINISHED'}

# Reset Operator
class MAPTYPE_OT_Reset(bpy.types.Operator):
    bl_idname = "maptype.reset"
    bl_label = "Reset Material"

    def execute(self, context):
        reset_selected_objects()
        return {'FINISHED'}

# Instructions Operator
class MAPTYPE_OT_Instructions(bpy.types.Operator):
    bl_idname = "maptype.instructions"
    bl_label = "Instructions"

    def execute(self, context):
        context.window_manager.popup_menu(show_instructions, title="T8 Texture Tool Instructions", icon='INFO')
        return {'FINISHED'}

# Register and Unregister
def register():
    bpy.utils.register_class(MAPTYPE_PT_Panel)
    bpy.utils.register_class(MAPTYPE_OT_Apply)
    bpy.utils.register_class(MAPTYPE_OT_Reset)
    bpy.utils.register_class(MAPTYPE_OT_Instructions)
    bpy.types.Scene.map_type = bpy.props.EnumProperty(
        items=[
            ("RMA", "RMA", ""),
            ("MRA", "MRA", ""),
            ("OBD", "OBD", ""),
            ("TSE", "TSE", ""),
            ("Color", "Color", ""),
            ("ID", "ID", "")
        ],
        name="Map Type"
    )

def unregister():
    bpy.utils.unregister_class(MAPTYPE_PT_Panel)
    bpy.utils.unregister_class(MAPTYPE_OT_Apply)
    bpy.utils.unregister_class(MAPTYPE_OT_Reset)
    bpy.utils.unregister_class(MAPTYPE_OT_Instructions)
    del bpy.types.Scene.map_type

if __name__ == "__main__":
    register()