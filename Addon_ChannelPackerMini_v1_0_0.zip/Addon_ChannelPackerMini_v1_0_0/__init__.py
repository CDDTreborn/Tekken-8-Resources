bl_info = {
    "name": "Channel Packer Add-on",
    "author": "Your Name",
    "version": (1, 1),
    "blender": (3, 6, 0),
    "location": "View3D > Tool Shelf",
    "description": "Add-on to manage Channel Packer node group",
    "category": "Material",
}

import bpy
from bpy.props import EnumProperty

def create_or_update_channel_packer_group():
    group_name = 'Channel Packer'
    
    # Check if the node group already exists
    if group_name in bpy.data.node_groups:
        # Update the existing node group
        node_group = bpy.data.node_groups[group_name]
        
        # Clear existing nodes and links
        node_group.nodes.clear()
        node_group.links.clear()
        
        # Remove existing inputs and outputs
        while node_group.inputs:
            node_group.inputs.remove(node_group.inputs[0])
        while node_group.outputs:
            node_group.outputs.remove(node_group.outputs[0])
    else:
        # Create a new node group
        node_group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    
    # Create inputs for the node group
    input_names_types = [
        ("Roughness", 'NodeSocketFloat'),
        ("Metallic", 'NodeSocketFloat'),
        ("AO", 'NodeSocketFloat'),
        ("Translucency", 'NodeSocketFloat'),
        ("Specular", 'NodeSocketFloat'),
        ("Emissive", 'NodeSocketFloat'),
        ("Opacity", 'NodeSocketFloat'),
        ("Dirt", 'NodeSocketFloat'),
        ("Color", 'NodeSocketColor'),
        ("ID", 'NodeSocketColor')
    ]
    for name, socket_type in input_names_types:
        node_group.inputs.new(socket_type, name)
        
    # Set default value of AO input to 1.0
    node_group.inputs['AO'].default_value = 1.0    
    
    
    
    # Create outputs for the node group
    output_names_types = [
        ("RMA", 'NodeSocketColor'),
        ("MRA", 'NodeSocketColor'),
        ("OBD", 'NodeSocketColor'),
        ("TSE", 'NodeSocketColor'),
        ("Color", 'NodeSocketColor'),
        ("ID", 'NodeSocketColor'),
        ("Color Desat", 'NodeSocketColor')
    ]
    for name, socket_type in output_names_types:
        node_group.outputs.new(socket_type, name)
    
    # Create Group Input and Group Output nodes
    group_input = node_group.nodes.new('NodeGroupInput')
    group_output = node_group.nodes.new('NodeGroupOutput')
    
    # Set positions for the input and output nodes
    group_input.location = (-800, 0)
    group_output.location = (800, 0)
    
    # Create Combine RGB nodes
    combine_rma = node_group.nodes.new('ShaderNodeCombineRGB')
    combine_mra = node_group.nodes.new('ShaderNodeCombineRGB')
    combine_obd = node_group.nodes.new('ShaderNodeCombineRGB')
    combine_tse = node_group.nodes.new('ShaderNodeCombineRGB')
    
    # Set positions for the Combine RGB nodes
    combine_rma.location = (-200, 300)
    combine_mra.location = (-200, 100)
    combine_obd.location = (-200, -100)
    combine_tse.location = (-200, -300)
    
    # Create Hue/Saturation node
    hue_sat_node = node_group.nodes.new('ShaderNodeHueSaturation')
    hue_sat_node.location = (-400, -500)
    hue_sat_node.inputs['Saturation'].default_value = 0.0  # Set saturation to 0.0
    
    # Create Brightness/Contrast node
    bright_contrast_node = node_group.nodes.new('ShaderNodeBrightContrast')
    bright_contrast_node.location = (-200, -500)
    bright_contrast_node.inputs['Bright'].default_value = 0.5  # Set brightness to 0.5
    
    # Reference the sockets by name
    # Link inputs to the Combine RGB nodes
    node_group.links.new(group_input.outputs['Roughness'], combine_rma.inputs['R'])  # Roughness -> R
    node_group.links.new(group_input.outputs['Metallic'], combine_rma.inputs['G'])   # Metallic -> G
    node_group.links.new(group_input.outputs['AO'], combine_rma.inputs['B'])         # AO -> B

    node_group.links.new(group_input.outputs['Metallic'], combine_mra.inputs['R'])   # Metallic -> R
    node_group.links.new(group_input.outputs['Roughness'], combine_mra.inputs['G'])  # Roughness -> G
    node_group.links.new(group_input.outputs['AO'], combine_mra.inputs['B'])         # AO -> B

    node_group.links.new(group_input.outputs['Opacity'], combine_obd.inputs['R'])    # Opacity -> R
    combine_obd.inputs['G'].default_value = 0.0                                      # G -> Static 0.0
    node_group.links.new(group_input.outputs['Dirt'], combine_obd.inputs['B'])       # Dirt -> B

    node_group.links.new(group_input.outputs['Translucency'], combine_tse.inputs['R'])  # Translucency -> R
    node_group.links.new(group_input.outputs['Specular'], combine_tse.inputs['G'])      # Specular -> G
    node_group.links.new(group_input.outputs['Emissive'], combine_tse.inputs['B'])      # Emissive -> B

    # Link Combine RGB nodes to the group outputs
    node_group.links.new(combine_rma.outputs['Image'], group_output.inputs['RMA'])
    node_group.links.new(combine_mra.outputs['Image'], group_output.inputs['MRA'])
    node_group.links.new(combine_obd.outputs['Image'], group_output.inputs['OBD'])
    node_group.links.new(combine_tse.outputs['Image'], group_output.inputs['TSE'])

    # Connect Color input to Color output
    node_group.links.new(group_input.outputs['Color'], group_output.inputs['Color'])
    
    # Connect ID input to ID output
    node_group.links.new(group_input.outputs['ID'], group_output.inputs['ID'])

    # Connect Color input to Hue/Saturation node
    node_group.links.new(group_input.outputs['Color'], hue_sat_node.inputs['Color'])
    
    # Connect Hue/Saturation node to Brightness/Contrast node
    node_group.links.new(hue_sat_node.outputs['Color'], bright_contrast_node.inputs['Color'])
    
    # Connect Brightness/Contrast node to Color Desat output
    node_group.links.new(bright_contrast_node.outputs['Color'], group_output.inputs['Color Desat'])

def connect_channel_packer_to_material(material, selected_output):
    # Ensure the 'Channel Packer' node group exists
    create_or_update_channel_packer_group()
    
    node_tree = material.node_tree
    
    # Find the Principled BSDF node
    bsdf_node = None
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            bsdf_node = node
            break
    if bsdf_node is None:
        print(f"No Principled BSDF node found in material '{material.name}'.")
        return
    
    # Check if the Channel Packer node already exists in the material
    channel_packer_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'Channel Packer':
            channel_packer_node = node
            break
    
    if channel_packer_node is None:
        # Add the 'Channel Packer' node group to the material
        channel_packer_node = node_tree.nodes.new('ShaderNodeGroup')
        channel_packer_node.node_tree = bpy.data.node_groups['Channel Packer']
        channel_packer_node.location = bsdf_node.location
        channel_packer_node.location.x += 400  # Adjust position as needed
    else:
        # Update the node_tree in case the node group was updated
        channel_packer_node.node_tree = bpy.data.node_groups['Channel Packer']
    
    # Define the inputs to process
    inputs_to_process = {
        'Base Color': 'Color',
        'Roughness': 'Roughness',
        'Metallic': 'Metallic',
        'Specular': 'Specular',
        'Alpha': 'Opacity',
        'Subsurface Color': 'ID'  # Added mapping
    }
    
    # Remove existing links to the Channel Packer inputs
    for input_name in channel_packer_node.inputs.keys():
        packer_input = channel_packer_node.inputs[input_name]
        while packer_input.is_linked:
            link = packer_input.links[0]
            node_tree.links.remove(link)
    
    # Set default value of AO input to 1.0
    if 'AO' in channel_packer_node.inputs:
        ao_input = channel_packer_node.inputs['AO']
        ao_input.default_value = 1.0
    
    # Loop through each input
    for bsdf_input_name, packer_input_name in inputs_to_process.items():
        if bsdf_input_name in bsdf_node.inputs and packer_input_name in channel_packer_node.inputs:
            bsdf_input = bsdf_node.inputs[bsdf_input_name]
            packer_input = channel_packer_node.inputs[packer_input_name]
            
            if bsdf_input.is_linked:
                # Get the link connected to the BSDF input
                bsdf_link = bsdf_input.links[0]
                from_node = bsdf_link.from_node
                from_socket = bsdf_link.from_socket
                
                # Check if the link already exists
                link_exists = False
                for link in node_tree.links:
                    if (link.from_socket == from_socket and link.to_socket == packer_input):
                        link_exists = True
                        break
                if not link_exists:
                    # Create a link from the source node to the Channel Packer input
                    node_tree.links.new(from_socket, packer_input)
            else:
                # Use the default value of the BSDF input
                if bsdf_input.type == 'RGBA':
                    packer_input.default_value = bsdf_input.default_value[:]
                else:
                    packer_input.default_value = bsdf_input.default_value

    # Connect the selected output of the Channel Packer to the BSDF Emission input
    if selected_output in channel_packer_node.outputs:
        # Remove existing links to the BSDF Emission input
        emission_input = bsdf_node.inputs['Emission']
        while emission_input.is_linked:
            link = emission_input.links[0]
            node_tree.links.remove(link)
        # Create a new link
        node_tree.links.new(channel_packer_node.outputs[selected_output], emission_input)
    else:
        print(f"Output '{selected_output}' not found in Channel Packer node.")

    # Arrange nodes by adjusting their positions
    arrange_nodes(node_tree, bsdf_node, channel_packer_node)

def arrange_nodes(node_tree, bsdf_node, channel_packer_node):
    # Position the Channel Packer node to the right of the BSDF node
    channel_packer_node.location = bsdf_node.location.copy()
    channel_packer_node.location.x += 400  # Adjust as needed
    
    # Position nodes connected to BSDF inputs to the left of the BSDF node
    processed_nodes = set()
    bsdf_inputs = ['Base Color', 'Roughness', 'Metallic', 'Specular', 'Alpha', 'Subsurface Color']  # Added 'Subsurface Color'
    for bsdf_input_name in bsdf_inputs:
        if bsdf_input_name in bsdf_node.inputs:
            bsdf_input = bsdf_node.inputs[bsdf_input_name]
            if bsdf_input.is_linked:
                from_node = bsdf_input.links[0].from_node
                if from_node not in processed_nodes:
                    from_node.location.x = bsdf_node.location.x - 400  # Adjust as needed
                    processed_nodes.add(from_node)
    
                    # Also move any nodes connected to the input node
                    for input_socket in from_node.inputs:
                        if input_socket.is_linked:
                            input_node = input_socket.links[0].from_node
                            if input_node not in processed_nodes:
                                input_node.location.x = from_node.location.x - 400
                                processed_nodes.add(input_node)

def clear_channel_packer_from_material(material):
    node_tree = material.node_tree
    nodes_to_remove = []
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'Channel Packer':
            nodes_to_remove.append(node)
    for node in nodes_to_remove:
        node_tree.nodes.remove(node)

class CHANNELPACKER_OT_Apply(bpy.types.Operator):
    bl_idname = "channelpacker.apply"
    bl_label = "Apply Channel Packer"
    bl_description = "Apply Channel Packer to selected objects"

    output_options = [
        ('RMA', 'RMA', ''),
        ('MRA', 'MRA', ''),
        ('OBD', 'OBD', ''),
        ('TSE', 'TSE', ''),
        ('Color', 'Color', ''),
        ('ID', 'ID', ''),
        ('Color Desat', 'Color Desat', ''),
    ]

    selected_output: EnumProperty(
        name="Select Output",
        description="Select output from Channel Packer node",
        items=output_options,
        default='RMA'
    )

    def execute(self, context):
        create_or_update_channel_packer_group()
        selected_objects = context.selected_objects
        for obj in selected_objects:
            if obj.type == 'MESH':
                for mat_slot in obj.material_slots:
                    material = mat_slot.material
                    if material:
                        connect_channel_packer_to_material(material, self.selected_output)
        self.report({'INFO'}, "Channel Packer applied to selected objects.")
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class CHANNELPACKER_OT_Clear(bpy.types.Operator):
    bl_idname = "channelpacker.clear"
    bl_label = "Clear Bake Nodes"
    bl_description = "Remove Channel Packer nodes from selected objects"

    def execute(self, context):
        selected_objects = context.selected_objects
        for obj in selected_objects:
            if obj.type == 'MESH':
                for mat_slot in obj.material_slots:
                    material = mat_slot.material
                    if material:
                        clear_channel_packer_from_material(material)
        self.report({'INFO'}, "Channel Packer nodes removed from selected objects.")
        return {'FINISHED'}

class CHANNELPACKER_PT_Panel(bpy.types.Panel):
    bl_label = "Channel Packer"
    bl_idname = "CHANNELPACKER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Channel Packer'

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("channelpacker.apply", text="Apply Channel Packer")

        row = layout.row()
        row.operator("channelpacker.clear", text="Clear Bake Nodes")

def register():
    bpy.utils.register_class(CHANNELPACKER_OT_Apply)
    bpy.utils.register_class(CHANNELPACKER_OT_Clear)
    bpy.utils.register_class(CHANNELPACKER_PT_Panel)

def unregister():
    bpy.utils.unregister_class(CHANNELPACKER_OT_Apply)
    bpy.utils.unregister_class(CHANNELPACKER_OT_Clear)
    bpy.utils.unregister_class(CHANNELPACKER_PT_Panel)

if __name__ == "__main__":
    register()
