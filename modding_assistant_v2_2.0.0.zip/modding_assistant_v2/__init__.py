# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Modding_Assistant_v2",
    "author" : "CDDT Reborn", 
    "description" : "Growing Panel of Tools aimed specifically at helping modders.",
    "blender" : (3, 6, 0),
    "version" : (2, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
modding_assist = {'sna_material_base': '', }


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_1ADAB(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_1ADAB, icon, active_data, active_propname, index_1ADAB):
        row = layout
        layout.prop(item_1ADAB, 'p_suffix', text=item_1ADAB.p_suffix, icon_value=0, emboss=True, index=0)


class SNA_OT_Set_Blend_Mode_Opaque_D9546(bpy.types.Operator):
    bl_idname = "sna.set_blend_mode_opaque_d9546"
    bl_label = "set_blend_mode_opaque"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_set_bld_mod_C6F97('OPAQUE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Blend_Mode_Alpha_Clip_71D9E(bpy.types.Operator):
    bl_idname = "sna.set_blend_mode_alpha_clip_71d9e"
    bl_label = "set_blend_mode_alpha_clip"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_set_bld_mod_C6F97('CLIP')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Blend_Mode_Alpha_Blend_6043F(bpy.types.Operator):
    bl_idname = "sna.set_blend_mode_alpha_blend_6043f"
    bl_label = "set_blend_mode_alpha_blend"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_set_bld_mod_C6F97('BLEND')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Blend_Mode_Alpha_Hashed_8Ef69(bpy.types.Operator):
    bl_idname = "sna.set_blend_mode_alpha_hashed_8ef69"
    bl_label = "set_blend_mode_alpha_hashed"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_set_bld_mod_C6F97('HASHED')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Clear_Duplicate_Mats_B562E(bpy.types.Operator):
    bl_idname = "sna.clear_duplicate_mats_b562e"
    bl_label = "clear_duplicate_mats"
    bl_description = "Duplicate Mats Set to Original"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        mats = bpy.data.materials
        for obj in bpy.data.objects:
            for slt in obj.material_slots:
                part = slt.name.rpartition('.')
                if part[2].isnumeric() and part[0] in mats:
                    slt.material = mats.get(part[0])
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def sna_set_bld_mod_C6F97(Blend_Mode):
    for i_36B87 in range(len(bpy.context.view_layer.objects.selected)):
        for i_5466E in range(len(bpy.context.active_object.material_slots)):
            bpy.context.active_object.material_slots[bpy.context.active_object.material_slots[i_5466E].material.name].material.blend_method = Blend_Mode


class SNA_PT_MATERIAL_ASSISTANT_E082B(bpy.types.Panel):
    bl_label = 'Material Assistant'
    bl_idname = 'SNA_PT_MATERIAL_ASSISTANT_E082B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Mod Assist'
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Set Material Blend Mode', icon_value=0)
        row_C4770 = layout.row(heading='Set Material Blend Mode', align=True)
        row_C4770.alert = False
        row_C4770.enabled = True
        row_C4770.active = True
        row_C4770.use_property_split = False
        row_C4770.use_property_decorate = False
        row_C4770.scale_x = 1.0
        row_C4770.scale_y = 1.0
        row_C4770.alignment = 'Expand'.upper()
        row_C4770.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_DAA79 = row_C4770.column(heading='', align=False)
        col_DAA79.alert = False
        col_DAA79.enabled = True
        col_DAA79.active = True
        col_DAA79.use_property_split = False
        col_DAA79.use_property_decorate = False
        col_DAA79.scale_x = 1.0
        col_DAA79.scale_y = 1.0
        col_DAA79.alignment = 'Expand'.upper()
        col_DAA79.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_DAA79.operator('sna.set_blend_mode_opaque_d9546', text='Opaque', icon_value=79, emboss=True, depress=False)
        op = col_DAA79.operator('sna.set_blend_mode_alpha_hashed_8ef69', text='A Hashed', icon_value=79, emboss=True, depress=False)
        col_E4B88 = row_C4770.column(heading='', align=False)
        col_E4B88.alert = False
        col_E4B88.enabled = True
        col_E4B88.active = True
        col_E4B88.use_property_split = False
        col_E4B88.use_property_decorate = False
        col_E4B88.scale_x = 1.0
        col_E4B88.scale_y = 1.0
        col_E4B88.alignment = 'Expand'.upper()
        col_E4B88.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E4B88.operator('sna.set_blend_mode_alpha_blend_6043f', text='A Blend', icon_value=79, emboss=True, depress=False)
        op = col_E4B88.operator('sna.set_blend_mode_alpha_clip_71d9e', text='A Clip', icon_value=79, emboss=True, depress=False)
        layout.label(text='Active Material Alpha On or Off', icon_value=0)
        col_ACC56 = layout.column(heading='', align=False)
        col_ACC56.alert = False
        col_ACC56.enabled = True
        col_ACC56.active = True
        col_ACC56.use_property_split = False
        col_ACC56.use_property_decorate = False
        col_ACC56.scale_x = 1.0
        col_ACC56.scale_y = 1.0
        col_ACC56.alignment = 'Expand'.upper()
        col_ACC56.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_4C2F6 = col_ACC56.row(heading='', align=False)
        row_4C2F6.alert = False
        row_4C2F6.enabled = True
        row_4C2F6.active = True
        row_4C2F6.use_property_split = False
        row_4C2F6.use_property_decorate = False
        row_4C2F6.scale_x = 1.0
        row_4C2F6.scale_y = 1.0
        row_4C2F6.alignment = 'Expand'.upper()
        row_4C2F6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_4C2F6.operator('sna.alpha_on_f3c26', text='On', icon_value=313, emboss=True, depress=False)
        op = row_4C2F6.operator('sna.alpha_off_e0ba3', text='Off', icon_value=324, emboss=True, depress=False)
        layout.label(text='Consolidate Materials', icon_value=0)
        op = layout.operator('sna.clear_duplicate_mats_b562e', text='Consolidate', icon_value=79, emboss=True, depress=False)


def sna_alpha_switch_D6783(On_or_Off):
    bpy.data.materials[bpy.context.active_object.material_slots[bpy.context.view_layer.objects.active.active_material_index].name].node_tree.nodes['Principled BSDF'].inputs[21].default_value = (1.0 if On_or_Off else 0.0)


class SNA_OT_Alpha_Off_E0Ba3(bpy.types.Operator):
    bl_idname = "sna.alpha_off_e0ba3"
    bl_label = "Alpha_Off"
    bl_description = "Alpha_Off"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_alpha_switch_D6783(False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Alpha_On_F3C26(bpy.types.Operator):
    bl_idname = "sna.alpha_on_f3c26"
    bl_label = "Alpha_On"
    bl_description = "Alpha_On"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_alpha_switch_D6783(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_node_assist_FAAC9(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_node_assist_FAAC9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_D4428 = layout.row(heading='', align=False)
        row_D4428.alert = False
        row_D4428.enabled = True
        row_D4428.active = True
        row_D4428.use_property_split = False
        row_D4428.use_property_decorate = False
        row_D4428.scale_x = 1.0
        row_D4428.scale_y = 1.0
        row_D4428.alignment = 'Expand'.upper()
        row_D4428.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('1ADAB', locals())
        row_D4428.template_list('SNA_UL_display_collection_list_1ADAB', coll_id, bpy.context.scene, 'sna_col_suffix', bpy.context.scene, 'sna_col_suffix', rows=0)


class SNA_OT_Tk7_Bone_Organizer_88773(bpy.types.Operator):
    bl_idname = "sna.tk7_bone_organizer_88773"
    bl_label = "tk7_bone_organizer"
    bl_description = "Bone Organizer for TK 7"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        # ```python
        #Description: TK7 Bone Organizer v2
        #Basic instruction: Copy and paste into Blender Script. Make sure the select the armature 
        #in object mode
        #Tested: Yes
        #Blender Version: 3.5, simple script should work in all versions.
        # TK7 Bone Organizer
        # In OBJECT mode, select Armature
        # Run Script
        # Primary bones will be on layer 16 and Finger bones on layer 17
        # Works best on fresh TK7 Armature. To reset make sure all layeres are selected
        # and change bone layer to 0.  
        bones = bpy.context.active_object.data.bones
        # These are the main bones that run thru the center of the body 
        # and have no left or right.
        pri_bones = [
            'Hip',
            'Spine1',
            'Spine2',
            'Neck',
            'Head'
            ]
        # These bones have a right and left
        sym_bones = [
            'Toe',
            'Foot',
            'Leg',
            'UpLeg',
            'Shoulder',
            'Arm',
            'ForeArm',
            'Hand',
            ]
        # These are for hand bone specifically
        hnd_bones = [
            'Thumb1',
            'Thumb2',
            'Thumb3',
            'Index1',
            'Index2',
            'Index3',
            'Middle1',
            'Middle2',
            'Middle3',
            'Ring1',
            'Ring2',
            'Ring3',
            'Pinky1',
            'Pinky2',
            'Pinky3'
            ]
        facA_bones = [
            'L_Eye_Joint',
            'R_Eye_Joint',
            'Jaw_Joint'
            ]
        facB_bones = [
            'L_UwaMabuta_Joint',
            'L_UpEyelid1',
            'L_UpEyelid2',
            'R_UwaMabuta_Joint',
            'R_UpEyelid1',
            'R_UpEyelid2',
            'L_SitaMabuta_Joint',
            'L_LowEyelid2',
            'L_LowEyelid1',
            'R_SitaMabuta_Joint',
            'R_LowEyelid2',
            'R_LowEyelid1',
            ]
        facC_bones = [
            'L_LipD_Joint',
            'R_LipD_Joint',
            'M_LipD_Joint',
            'L_LipE_Joint',
            'R_LipE_Joint',
            'L_LipU_Joint',
            'R_LipU_Joint',
            'M_LipU_Joint',
            ]
        facD_bones = [
            'L_Mayu1_Joint',
            'L_Mayu2_Joint',
            'L_Mayu3_Joint',
            'R_Mayu1_Joint',
            'R_Mayu2_Joint',
            'R_Mayu3_Joint',
            ]
        # Follow the examples above for establishing your own groups in 
        # case you want more specific groups on different layers.
        # The bone layer numbers are from left to right then the next level starting from the 
        # the left and spanning all the way to the left past the gap then starting on the next layer.
        # 1-7, 8-15
        # 16-23, 24-32 
        for i in pri_bones:
            layer = 16
            bones[i].layers[layer] = True
        for i in facA_bones:
            layer = 8
            bones[i].layers[layer] = True
        for i in facB_bones:
            layer = 9
            bones[i].layers[layer] = True
        for i in facC_bones:
            layer = 10
            bones[i].layers[layer] = True
        for i in facD_bones:
            layer = 11
            bones[i].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        # ```
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_BONE_ORGANIZER_17B94(bpy.types.Panel):
    bl_label = 'Bone Organizer'
    bl_idname = 'SNA_PT_BONE_ORGANIZER_17B94'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Mod Assist'
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.tk7_bone_organizer_88773', text='Tekken 7', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.tk8_bone_organizer_msl_4b733', text='Tekken 8 MSL', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.tk8_bone_organizer_prp_52fd6', text='Tekken 8 PRP', icon_value=0, emboss=True, depress=False)
        layout.label(text='Armature Edit Mode Tools', icon_value=0)
        op = layout.operator('armature.align', text='Align Bone to Active Bone', icon_value=0, emboss=True, depress=False)


class SNA_OT_Tk8_Bone_Organizer_Msl_4B733(bpy.types.Operator):
    bl_idname = "sna.tk8_bone_organizer_msl_4b733"
    bl_label = "tk8_bone_organizer_msl"
    bl_description = "Bone Organizer for TK 8 MSL"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        # ```python
        #Description: TK7 Bone Organizer v2
        #Basic instruction: Copy and paste into Blender Script. Make sure the select the armature 
        #in object mode
        #Tested: Yes
        #Blender Version: 3.5, simple script should work in all versions.
        # TK7 Bone Organizer
        # In OBJECT mode, select Armature
        # Run Script
        # Primary bones will be on layer 16 and Finger bones on layer 17
        # Works best on fresh TK7 Armature. To reset make sure all layeres are selected
        # and change bone layer to 0.  
        bones = bpy.context.active_object.data.bones
        # These are the main bones that run thru the center of the body 
        # and have no left or right.
        pri_bones = [
            'Hip', #
            'C_Leg', # Main Hip Bone
            'Spine1', #
            'Spine2', #
            'Neck', #
            'Head', #
            'ADR_L_Bust_drv', # New
            'ADR_R_Bust_drv', # New
            'ADR_L_Shoulder_drv', # New
            'ADR_R_Shoulder_drv', # New
            'SWG_L_Bust', # New
            'SWG_R_Bust', # New
            'ADR_NeckSpine_twt_c', # New
            'ADR_L_DeltioidUp_bnd', # New
            'ADR_R_DeltioidUp_bnd', # New
            'ADR_L_Deltoid_drv', # New
            'ADR_R_Deltoid_drv' # New
            ]
        # These bones have a right and left
        sym_bones = [
            'Toe', #
            'Foot', #
            'LowerLeg', # Leg
            'UpperLeg', # UpLeg
            'Shoulder', # Shoulder
            'UpperArm', # Arm
            'LowerArm', # ForeArm
            'Hand', #
            ]
        # These are for hand bone specifically
        hnd_bones = [
            'Thumb0',
            'Thumb1',
            'Thumb2',
            'Index0',
            'Index1',
            'Index2',
            'Index3',
            'Middle0',
            'Middle1',
            'Middle2',
            'Middle3',
            'Ring0',
            'Ring1',
            'Ring2',
            'Ring3',
            'Pinky0',
            'Pinky1',
            'Pinky2',
            'Pinky3'
            ]
        facA_bones = [
            'L_Eye_Joint',
            'R_Eye_Joint',
            'Jaw_Joint'
            ]
        facB_bones = [
            'L_UwaMabuta_Joint',
            'L_UpEyelid1',
            'L_UpEyelid2',
            'R_UwaMabuta_Joint',
            'R_UpEyelid1',
            'R_UpEyelid2',
            'L_SitaMabuta_Joint',
            'L_LowEyelid2',
            'L_LowEyelid1',
            'R_SitaMabuta_Joint',
            'R_LowEyelid2',
            'R_LowEyelid1',
            ]
        facC_bones = [
            'L_LipD_Joint',
            'R_LipD_Joint',
            'M_LipD_Joint',
            'L_LipE_Joint',
            'R_LipE_Joint',
            'L_LipU_Joint',
            'R_LipU_Joint',
            'M_LipU_Joint',
            ]
        facD_bones = [
            'L_Mayu1_Joint',
            'L_Mayu2_Joint',
            'L_Mayu3_Joint',
            'R_Mayu1_Joint',
            'R_Mayu2_Joint',
            'R_Mayu3_Joint',
            ]
        # Follow the examples above for establishing your own groups in 
        # case you want more specific groups on different layers.
        # The bone layer numbers are from left to right then the next level starting from the 
        # the left and spanning all the way to the left past the gap then starting on the next layer.
        # 1-7, 8-15
        # 16-23, 24-32 
        for i in pri_bones:
            layer = 16
            bones[i].layers[layer] = True
        #for i in facA_bones:
        #    layer = 8
        #    bones[i].layers[layer] = True
        #for i in facB_bones:
        #    layer = 9
        #    bones[i].layers[layer] = True
        #    
        #for i in facC_bones:
        #    layer = 10
        #    bones[i].layers[layer] = True
        #    
        #for i in facD_bones:
        #    layer = 11
        #    bones[i].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        # ```
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Tk8_Bone_Organizer_Prp_52Fd6(bpy.types.Operator):
    bl_idname = "sna.tk8_bone_organizer_prp_52fd6"
    bl_label = "tk8_bone_organizer_prp"
    bl_description = "Bone Organizer for TK 8 PRP"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        # ```python
        #Description: TK7 Bone Organizer v2
        #Basic instruction: Copy and paste into Blender Script. Make sure the select the armature 
        #in object mode
        #Tested: Yes
        #Blender Version: 3.5, simple script should work in all versions.
        # TK7 Bone Organizer
        # In OBJECT mode, select Armature
        # Run Script
        # Primary bones will be on layer 16 and Finger bones on layer 17
        # Works best on fresh TK7 Armature. To reset make sure all layeres are selected
        # and change bone layer to 0.  
        bones = bpy.context.active_object.data.bones
        # These are the main bones that run thru the center of the body 
        # and have no left or right.
        pri_bones = [
            'Hip_prp', #
        #    'C_Leg', # Main Hip Bone
            'Spine1_prp', #
            'Spine2_prp', #
            'Neck_prp', #
            'Head_prp', #
        #    'ADR_L_Bust_drv', # New
        #    'ADR_R_Bust_drv', # New
        #    'ADR_L_Shoulder_drv', # New
        #    'ADR_R_Shoulder_drv', # New
        #    'SWG_L_Bust', # New
        #    'SWG_R_Bust', # New
        #    'ADR_NeckSpine_twt_c', # New
        #    'ADR_L_DeltioidUp_bnd', # New
        #    'ADR_R_DeltioidUp_bnd', # New
        #    'ADR_L_Deltoid_drv', # New
        #    'ADR_R_Deltoid_drv', # New
            'Chest__offset_prp' # New
            ]
        # These bones have a right and left
        sym_bones = [
            'Toe_prp', # Toe
            'Foot_prp', # Foot
            'LowerLeg_prp', # Leg
            'UpperLeg_prp', # UpLeg
            'Shoulder_prp', # Shoulder
            'UpperArm_prp', # Arm
            'LowerArm_prp', # ForeArm
            'Hand_prp', # Hand
            'Bust__offset_prp' # New
            ]
        # These are for hand bone specifically
        hnd_bones = [
            'Thumb0_prp',
            'Thumb1_prp',
            'Thumb2_prp',
            'Index0_prp',
            'Index1_prp',
            'Index2_prp',
            'Index3_prp',
            'Middle0_prp',
            'Middle1_prp',
            'Middle2_prp',
            'Middle3_prp',
            'Ring0_prp',
            'Ring1_prp',
            'Ring2_prp',
            'Ring3_prp',
            'Pinky0_prp',
            'Pinky1_prp',
            'Pinky2_prp',
            'Pinky3_prp'
            ]
        facA_bones = [
            'L_Eye_Joint',
            'R_Eye_Joint',
            'Jaw_Joint'
            ]
        facB_bones = [
            'L_UwaMabuta_Joint',
            'L_UpEyelid1',
            'L_UpEyelid2',
            'R_UwaMabuta_Joint',
            'R_UpEyelid1',
            'R_UpEyelid2',
            'L_SitaMabuta_Joint',
            'L_LowEyelid2',
            'L_LowEyelid1',
            'R_SitaMabuta_Joint',
            'R_LowEyelid2',
            'R_LowEyelid1',
            ]
        facC_bones = [
            'L_LipD_Joint',
            'R_LipD_Joint',
            'M_LipD_Joint',
            'L_LipE_Joint',
            'R_LipE_Joint',
            'L_LipU_Joint',
            'R_LipU_Joint',
            'M_LipU_Joint',
            ]
        facD_bones = [
            'L_Mayu1_Joint',
            'L_Mayu2_Joint',
            'L_Mayu3_Joint',
            'R_Mayu1_Joint',
            'R_Mayu2_Joint',
            'R_Mayu3_Joint',
            ]
        # Follow the examples above for establishing your own groups in 
        # case you want more specific groups on different layers.
        # The bone layer numbers are from left to right then the next level starting from the 
        # the left and spanning all the way to the left past the gap then starting on the next layer.
        # 1-7, 8-15
        # 16-23, 24-32 
        for i in pri_bones:
            layer = 16
            bones[i].layers[layer] = True
        #for i in facA_bones:
        #    layer = 8
        #    bones[i].layers[layer] = True
        #for i in facB_bones:
        #    layer = 9
        #    bones[i].layers[layer] = True
        #    
        #for i in facC_bones:
        #    layer = 10
        #    bones[i].layers[layer] = True
        #    
        #for i in facD_bones:
        #    layer = 11
        #    bones[i].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in hnd_bones:
            layer = 17
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "L_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        for i in sym_bones:
            layer = 16
            side = "R_"
            act_bone = side + i
            bones[act_bone].layers[layer] = True
        # ```
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_QUICKSAVE_67856(bpy.types.Panel):
    bl_label = 'QuickSave'
    bl_idname = 'SNA_PT_QUICKSAVE_67856'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Mod Assist'
    bl_order = 0
    bl_options = {'HIDE_HEADER', 'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('wm.save_mainfile', text='Save File', icon_value=0, emboss=True, depress=False)
        col_A734D = layout.column(heading='Quick Tools', align=False)
        col_A734D.alert = False
        col_A734D.enabled = True
        col_A734D.active = True
        col_A734D.use_property_split = False
        col_A734D.use_property_decorate = False
        col_A734D.scale_x = 1.0
        col_A734D.scale_y = 1.0
        col_A734D.alignment = 'Expand'.upper()
        col_A734D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"


class SNA_GROUP_sna_pg_suffix(bpy.types.PropertyGroup):
    p_suffix: bpy.props.StringProperty(name='p_suffix', description='User_Suffix', default='', subtype='NONE', maxlen=0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_pg_suffix)
    bpy.types.Scene.sna_duplicate_mat_popup = bpy.props.StringProperty(name='Duplicate Mat PopUp', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_col_suffix = bpy.props.CollectionProperty(name='col_suffix', description='', type=SNA_GROUP_sna_pg_suffix)
    bpy.utils.register_class(SNA_OT_Set_Blend_Mode_Opaque_D9546)
    bpy.utils.register_class(SNA_OT_Set_Blend_Mode_Alpha_Clip_71D9E)
    bpy.utils.register_class(SNA_OT_Set_Blend_Mode_Alpha_Blend_6043F)
    bpy.utils.register_class(SNA_OT_Set_Blend_Mode_Alpha_Hashed_8Ef69)
    bpy.utils.register_class(SNA_OT_Clear_Duplicate_Mats_B562E)
    bpy.utils.register_class(SNA_PT_MATERIAL_ASSISTANT_E082B)
    bpy.utils.register_class(SNA_OT_Alpha_Off_E0Ba3)
    bpy.utils.register_class(SNA_OT_Alpha_On_F3C26)
    bpy.utils.register_class(SNA_PT_node_assist_FAAC9)
    bpy.utils.register_class(SNA_UL_display_collection_list_1ADAB)
    bpy.utils.register_class(SNA_OT_Tk7_Bone_Organizer_88773)
    bpy.utils.register_class(SNA_PT_BONE_ORGANIZER_17B94)
    bpy.utils.register_class(SNA_OT_Tk8_Bone_Organizer_Msl_4B733)
    bpy.utils.register_class(SNA_OT_Tk8_Bone_Organizer_Prp_52Fd6)
    bpy.utils.register_class(SNA_PT_QUICKSAVE_67856)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_col_suffix
    del bpy.types.Scene.sna_duplicate_mat_popup
    bpy.utils.unregister_class(SNA_GROUP_sna_pg_suffix)
    bpy.utils.unregister_class(SNA_OT_Set_Blend_Mode_Opaque_D9546)
    bpy.utils.unregister_class(SNA_OT_Set_Blend_Mode_Alpha_Clip_71D9E)
    bpy.utils.unregister_class(SNA_OT_Set_Blend_Mode_Alpha_Blend_6043F)
    bpy.utils.unregister_class(SNA_OT_Set_Blend_Mode_Alpha_Hashed_8Ef69)
    bpy.utils.unregister_class(SNA_OT_Clear_Duplicate_Mats_B562E)
    bpy.utils.unregister_class(SNA_PT_MATERIAL_ASSISTANT_E082B)
    bpy.utils.unregister_class(SNA_OT_Alpha_Off_E0Ba3)
    bpy.utils.unregister_class(SNA_OT_Alpha_On_F3C26)
    bpy.utils.unregister_class(SNA_PT_node_assist_FAAC9)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_1ADAB)
    bpy.utils.unregister_class(SNA_OT_Tk7_Bone_Organizer_88773)
    bpy.utils.unregister_class(SNA_PT_BONE_ORGANIZER_17B94)
    bpy.utils.unregister_class(SNA_OT_Tk8_Bone_Organizer_Msl_4B733)
    bpy.utils.unregister_class(SNA_OT_Tk8_Bone_Organizer_Prp_52Fd6)
    bpy.utils.unregister_class(SNA_PT_QUICKSAVE_67856)
